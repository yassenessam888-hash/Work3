# قالب موقع خفيف (HTML + CSS + JavaScript)

موقع متجاوب بدون أطر عمل أو مكتبات. افتح `index.html` مباشرة في المتصفح (يعمل دون إنترنت).

## هيكل الملفات
```
index.html      ← المحتوى (النصوص والأقسام)
css/style.css   ← الألوان والخطوط والتنسيق
js/main.js      ← القائمة، التحقق من النموذج، زر الأعلى
images/         ← الصور (حاليًا صور SVG مؤقتة)
```

## تغيير الألوان
افتح `css/style.css` وعدّل المتغيرات في أعلى الملف داخل `:root`:
`--color-primary` (الرأس والتذييل)، `--color-accent` (الأزرار)، `--color-bg`، `--color-text`.

## تغيير الخطوط
في `css/style.css` عدّل `--font-body` و `--font-heading`.
الخطوط الحالية هي خطوط النظام (أسرع تحميلًا وتعمل دون اتصال).
لاستخدام خط خاص: ضع ملف `.woff2` في مجلد `fonts/` وأضف في أعلى `style.css`:
```css
@font-face {
  font-family: "خطي";
  src: url("../fonts/font.woff2") format("woff2");
  font-display: swap;
}
```
ثم اجعل `--font-body: "خطي", system-ui, sans-serif;`

## تغيير النصوص والصور
- النصوص: داخل `index.html` (ابحث عن "اسم موقعك" والنصوص المؤقتة).
- الصور: استبدل الملفات في `images/` بنفس الأسماء، أو غيّر `src` في `index.html`.
  استخدم صور WebP/JPG مضغوطة، وحافظ على `width` و `height` لتجنب اهتزاز التخطيط.
- العنوان والوصف: وسما `<title>` و `<meta name="description">` في أعلى `index.html`.

## إضافة قسم جديد
انسخ قسمًا كاملًا `<section class="section"> ... </section>` وغيّر `id` ومحتواه،
ثم أضف رابطًا له في القائمة (`<nav>`) والتذييل.

## تحويل الموقع إلى الإنجليزية (اتجاه من اليسار)
في أول `index.html` غيّر `<html lang="ar" dir="rtl">` إلى `<html lang="en" dir="ltr">`.
التنسيق يستخدم خصائص منطقية، لذا ينقلب التخطيط تلقائيًا. عدّل رسائل التحقق في `js/main.js` (`MESSAGES`).

## ربط نموذج التواصل بخدمة حقيقية
النموذج حاليًا للعرض فقط. للإرسال الفعلي:
1. ضع رابط خدمة النماذج (مثل Formspree أو Netlify Forms) في `action` داخل `<form>`.
2. في `js/main.js` احذف الأسطر الثلاثة الواردة بعد التعليق "نسخة العرض" (`e.preventDefault()` ورسالة النجاح و`form.reset()`).

## النشر على GitHub Pages
1. أنشئ مستودعًا جديدًا وارفع محتويات المجلد (يجب أن يكون `index.html` في الجذر).
2. من Settings ← Pages اختر Branch: `main` و Folder: `/ (root)` ثم Save.
3. بعد دقيقة يظهر الرابط: `https://اسمك.github.io/اسم-المستودع/`

## الاختبار
- التوافق مع الجوال: اختبر الرابط المنشور في https://search.google.com/test/mobile-friendly (قد تتغير الأداة، وبديلها Lighthouse في Chrome).
- الأداء: في Chrome اضغط F12 ← Lighthouse ← Desktop ← Analyze.
