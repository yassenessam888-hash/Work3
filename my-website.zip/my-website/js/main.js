/* =========================================================
   السكربت الرئيسي (JavaScript عادي بدون مكتبات)
   1) قائمة التنقل القابلة للطي  2) التحقق من النموذج
   3) زر العودة للأعلى  4) سنة التذييل
   ========================================================= */
(function () {
  'use strict';

  /* ---------- 1) قائمة التنقل على الهاتف ---------- */
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('siteNav');

  function setMenu(open) {
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
  }

  toggle.addEventListener('click', function () {
    setMenu(toggle.getAttribute('aria-expanded') !== 'true');
  });
  // إغلاق القائمة عند اختيار رابط
  nav.addEventListener('click', function (e) {
    if (e.target.tagName === 'A') setMenu(false);
  });
  // إغلاق القائمة بمفتاح Esc
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') setMenu(false);
  });

  /* ---------- 2) التحقق من النموذج ----------
     عدّل الرسائل هنا لتغيير النصوص */
  var MESSAGES = {
    name:    { empty: 'يرجى إدخال اسمك.', short: 'الاسم قصير جدًا (حرفان على الأقل).' },
    email:   { empty: 'يرجى إدخال بريدك الإلكتروني.', invalid: 'صيغة البريد الإلكتروني غير صحيحة.' },
    message: { empty: 'يرجى كتابة رسالتك.', short: 'الرسالة قصيرة جدًا (10 أحرف على الأقل).' }
  };

  var form = document.getElementById('contactForm');
  var status = document.getElementById('formStatus');

  function validateField(field) {
    var value = field.value.trim();
    var m = MESSAGES[field.name];
    var msg = '';

    if (!value) msg = m.empty;
    else if (field.name === 'name' && value.length < 2) msg = m.short;
    else if (field.name === 'message' && value.length < 10) msg = m.short;
    else if (field.name === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) msg = m.invalid;

    document.getElementById(field.id + '-error').textContent = msg;
    field.setAttribute('aria-invalid', msg ? 'true' : 'false');
    return !msg;
  }

  var fields = form.querySelectorAll('input, textarea');
  fields.forEach(function (f) {
    f.addEventListener('blur', function () { validateField(f); });
    f.addEventListener('input', function () {
      if (f.getAttribute('aria-invalid') === 'true') validateField(f);
    });
  });

  form.addEventListener('submit', function (e) {
    var firstInvalid = null;
    fields.forEach(function (f) {
      if (!validateField(f) && !firstInvalid) firstInvalid = f;
    });

    if (firstInvalid) {
      e.preventDefault();
      status.textContent = '';
      firstInvalid.focus();
      return;
    }

    // نسخة العرض: لا يوجد خادم، لذا نعرض رسالة نجاح فقط.
    // عند ربط النموذج بخدمة حقيقية احذف الأسطر الثلاثة التالية (راجع README).
    e.preventDefault();
    status.textContent = 'تم التحقق من البيانات بنجاح. (نسخة تجريبية: لم تُرسل الرسالة)';
    form.reset();
  });

  /* ---------- 3) زر العودة إلى أعلى الصفحة ---------- */
  var toTop = document.getElementById('toTop');
  var ticking = false;

  window.addEventListener('scroll', function () {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      toTop.hidden = window.scrollY < 400;
      ticking = false;
    });
  }, { passive: true });

  toTop.addEventListener('click', function () {
    window.scrollTo({ top: 0 });
  });

  /* ---------- 4) سنة التذييل التلقائية ---------- */
  document.getElementById('year').textContent = new Date().getFullYear();
})();
